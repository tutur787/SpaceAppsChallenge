from .loader import t, set_lang, get_lang, get_language_label, AVAILABLE_LANGS

__all__ = ["t", "set_lang", "get_lang", "get_language_label", "AVAILABLE_LANGS"]
