"""Test package for SpaceAppsChallenge."""
